package com.cg.stpdef;


import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.cg.pom.Pomclass;
import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;		
public class stepdef 
{				
 	WebDriver d ;
 	
  	Pomclass pom;
  	Pomclass pom1;
  	Pomclass pom2;
 @Before
 public void bs()
 {
	 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
 	  d=new ChromeDriver();
	//System.setProperty("webdriver.gecko.driver","d:\\geckodriver.exe");
	 //d=new FirefoxDriver();
 }
  	
  	@Given("^Open conference web page$")
  	public void open_conference_web_page() 
  	{
  		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
  	  //d=new ChromeDriver();
          d.get("file:\\c:\\ConferenceRegistartion.html");
          //d.get("file:C:\\Coaching_Class_Enquiry.html");

          d.manage().window().maximize();
         // file:///C:/ConferenceRegistartion.html
  	  
  	}
  	@Given("^Open payment details web page$")
  	public void open_payment_web_page() 
  	{
  		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Downloads\\chromedriver.exe");
  	  //d=new ChromeDriver();
          d.get("file:\\c:\\PaymentDetails.html");
          d.manage().window().maximize();
  	  
  	}
  	

  	@Then("^verify title$")
  	public void verify_title() throws Throwable 
  	{

 		 String a=d.getTitle();
 		    if(a.equalsIgnoreCase("Conference Registartion")) 
 		    {
 		        System.out.println("Title is correct-No defect");

 		    }
 		    else
 		    {
 		        System.out.println("Title is not correct-A defect");
 		    }
 			
  	
  	}

  	@When("^firstname blank and click next$")
  	public void firstname_blank_and_click_next(DataTable dt) throws Throwable
  	{
 List<List<String>> data = dt.raw();
  		 
  		 
  	     pom=new Pomclass(d);

  		 pom.firstname(data.get(0).get(0));

  		 pom.next();
  	
  	}

  	@Then("^alert message for entering comes$")
  	public void alert_message_for_entering_comes() 
  	{
  		 try
 		  {
 			  String t=d.switchTo().alert().getText();
 			  d.switchTo().alert().accept();

 			  System.out.println(t);

 			  if(t.equalsIgnoreCase("Please fill the First Name"))
 			  {
 				  System.out.println("on not entering first name and clicking next and alert appeared-No defect");
 			  }
 			  else
 			  {
 				  System.out.println("on not entering first name and clicking next and alert did not appeared-A defect");

 			  }
 		  }
 		  catch(Exception e)
 		  {
 			  System.out.println("alert did not appear");
 		  }
  	  
  	}

  	@When("^firstname entered lastname blank and click next$")
  	public void firstname_entered_lastname_blank_and_click_next(DataTable dt) 
  	{
  	
 List<List<String>> data = dt.raw();
  		 
  		 
  	     pom=new Pomclass(d);

  		 pom.firstname(data.get(0).get(0));
  		 pom.lastname(data.get(0).get(1));
  		 pom.next();
  	}

  	@Then("^alert message for entering comesa$")
  	public void alert_message_for_entering_comes1() 
  	{

 		 try
 		  {
 			  String t=d.switchTo().alert().getText();
 			  d.switchTo().alert().accept();

 			  System.out.println(t);

 			  if(t.equalsIgnoreCase("Please fill the Last Name"))
 			  {
 				  System.out.println("on entering first name and not entering last name and clicking next an alert appeared-No defect");
 			  }
 			  else
 			  {
 				  System.out.println("on entering first name and not entering last name and clicking next an alert did not appeared-A defect");

 			  }
 		  }
 		  catch(Exception e)
 		  {
 			  System.out.println("alert did not appear");
 		  }
  		
  	
  	}

  	@When("^enter fn ln em blank \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_fn_ln_em_blank_and_and(String fn1, String ln1, String em)
  	{
  		
  		 pom2=new Pomclass(d);
  	     pom2.firstname(fn1);
  	     pom2.lastname(ln1);
  	     pom2.email1(em);
  	     pom2.next();
  	   
  	}

  	@Then("^alert message for email comes$")
  	public void alert_message_for_email_comes()  
  	{
  		 try
 		  {
 			  String t=d.switchTo().alert().getText();
 			  d.switchTo().alert().accept();

 			  System.out.println(t);

 			  if(t.equalsIgnoreCase("Please fill the Email"))
 			  {
 				  System.out.println("on entering first name and entering last name and not entering email and clicking next an alert with text appeared-No defect");
 			  }
 			  else
 			  {
 				  System.out.println("on entering first name and entering last name and entering email and clicking next an alert with text did not appeared-A defect");

 			  }
 		  }
 		  catch(Exception e)
 		  {
 			  System.out.println("alert did not appear");
 		  }     
  	  
  	}

  	@When("^enter fn ln em cn blank \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_fn_ln_em_cn_blank_and_and_and(String fn, String ln, String em, String contact) 
  	{
  		 pom1=new Pomclass(d);
  	     pom1.firstname(fn);
  	     pom1.lastname(ln);
  	     pom1.email1(em);
  	     pom1.contact(contact);

  	     pom1.next();
  	   
  	}

  	@Then("^alert message for contact comes$")
  	public void alert_message_for_contact_comes() 
  	{

 		 try
 		  {
 			  String t1=d.switchTo().alert().getText();
 			  d.switchTo().alert().accept();

 			  System.out.println(t1);

 			  if(t1.equalsIgnoreCase("Please fill the Contact No."))
 			  {
 				  System.out.println("on entering first name and entering last name and entering email and not entering contact no. and clicking next an alert with text appeared-No defect");
 			  }
 			  else
 			  {
 				  System.out.println("on entering first name and entering last name and entering email and not entering contact no. and clicking next an alert with text did not appear-A defect");

 			  }
 		  }
 		  catch(Exception e)
 		  {
 			  System.out.println("alert did not appear");
 		  }

  	 
  	}

  	@When("^enter fn ln em cn np blank \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_fn_ln_em_cn_np_blank_and_and_and_and(String fn, String ln, String em, String cn, String np) 
  	{
  		 pom1=new Pomclass(d);
  	     pom1.firstname(fn);
  	     pom1.lastname(ln);
  	     pom1.email1(em);
  	     pom1.contact(cn);
  	     pom1.number(np);

  	     pom1.next();
  	
  	}

  	@Then("^alert message for number of people comes$")
  	public void alert_message_for_number_of_people_comes()
  	{
  	
  		try
  	  {
  		  String t1=d.switchTo().alert().getText();
  		  d.switchTo().alert().accept();

  		  System.out.println(t1);

  		  if(t1.equalsIgnoreCase("Please fill the Number of people attending"))
  		  {
  			  System.out.println("on entering first name and entering last name and entering email and entering contact no. and not entering number of people and clicking next an alert appeared-No defect");
  		  }
  		  else
  		  {
  			  System.out.println("on entering first name and entering last name and entering email and entering contact no. and not entering number of people and clicking next an alert did not appear-A defect");

  		  }
  	  }
  	  catch(Exception e)
  	  {
  		  System.out.println("alert did not appear");
  	  }
  	}

  	@When("^enter fn ln em cn np bn blank  \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_fn_ln_em_cn_np_bn_blank_and_and_and_and_and(String fn, String ln, String em, String cn, String np, String b) 
  	{
  		 pom1=new Pomclass(d);
  	     pom1.firstname(fn);
  	     pom1.lastname(ln);
  	     pom1.email1(em);
  	     pom1.contact(cn);
  	     pom1.number(np);
  	     pom1.building(b);
  	     pom1.next();
  
  	}

  	@Then("^alert message for building name and room no\\. comes$")
  	public void alert_message_for_building_name_and_room_no_comes() 
  	{

    	  try
  	  {
  		  String t1=d.switchTo().alert().getText();
  		  d.switchTo().alert().accept();

  		  System.out.println(t1);

  		  if(t1.equalsIgnoreCase("Please fill the Building & Room No"))
  		  {
  			  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and not entering building name and room no. and clicking next an alert appeared-No defect");
  		  }
  		  else
  		  {
  			  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and not entring building name and room no. and clicking next an alert did not appear-A defect");

  		  }
  	  }
  	  catch(Exception e)
  	  {
  		  System.out.println("alert did not appear");
  	  }
  	}

  	@When("^enter fn ln em cn np bn an blank \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_fn_ln_em_cn_np_bn_an_blank_and_and_and_and_and_and(String fn, String ln, String em, String cn, String np, String bn, String an) 
  	{
  	   

 		 pom1=new Pomclass(d);
 		 
 	     pom1.firstname(fn);
 	     pom1.lastname(ln);
 	     pom1.email1(em);
 	     pom1.contact(cn);
 	     pom1.number(np);
 	     pom1.building(bn);
 	     pom1.area(an);
 	     pom1.next();
  	}

  	@Then("^alert message for area name comes$")
  	public void alert_message_for_area_name_comes()
  	{
  		 try
 		  {
 			  String t1=d.switchTo().alert().getText();
 			  d.switchTo().alert().accept();

 			  System.out.println(t1);

 			  if(t1.equalsIgnoreCase("Please fill the Area name"))
 			  {
 				  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and entering building name and room no. and not entering area name and clicking next an alert appeared-No defect");
 			  }
 			  else
 			  {
 				  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and not entring building name and room no. and not entering area name and clicking next an alert did not appear-A defect");

 			  }
 		  }
 		  catch(Exception e)
 		  {
 			  System.out.println("alert did not appear");
 		  }
  	  
  	}

  	@When("^enter fn ln em cn np bn an city blank \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_fn_ln_em_cn_np_bn_an_city_blank_and_and_and_and_and_and_and(String fn, String ln, String em, String cn, String np, String bn, String an, String city)
  	{
  	 
  		 pom1=new Pomclass(d);
  	     pom1.firstname(fn);
  	     pom1.lastname(ln);
  	     pom1.email1(em);
  	     pom1.contact(cn);
  	     pom1.number(np);
  	     pom1.building(bn);
  	     pom1.area(an);
  	     pom1.city(city);
  	     pom1.next();
  	}

  	@Then("^alert message for city comes$")
  	public void alert_message_for_city_comes()
  	{
  		try
    	  {
    		  String t1=d.switchTo().alert().getText();
    		  d.switchTo().alert().accept();

    		  System.out.println(t1);

    		  if(t1.equalsIgnoreCase("Please select city"))
    		  {
    			  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and entering building name and room no. and entering area name and not selecting city and clicking next an alert appeared-No defect");
    		  }
    		  else
    		  {
    			  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and entering building name and room no. and entering area name and not selecting city and clicking next an alert did not appear-A defect");

    		  }
    	  }
    	  catch(Exception e)
    	  {
    		  System.out.println("alert did not appear");
    	  }
  	}

  	@When("^enter fn ln em cn np bn an city state blank \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_fn_ln_em_cn_np_bn_an_city_state_blank_and_and_and_and_and_and_and_and(String fn, String ln, String em, String cn, String np, String bn, String an, String city, String state) 
  	{
  		pom=new Pomclass(d);
 	     pom.firstname(fn);
 	     pom.lastname(ln);
 	     pom.email1(em);
 	     pom.contact(cn);
 	     pom.number(np);	
 	     pom.building(bn); 
 	     pom.area(an);
 	     pom.city(city);
 	     pom.state(state);
 	     pom.next();
  	}

  	@Then("^alert message for state comes$")
  	public void alert_message_for_state_comes() 
  	{
  		 try
 		  {
 			  String t1=d.switchTo().alert().getText();
 			  d.switchTo().alert().accept();

 			  System.out.println(t1);

 			  if(t1.equalsIgnoreCase("Please select state"))
 			  {
 				  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and entering building name and room no. and entering area name and not selecting city and clicking next an alert appeared-No defect");
 			  }
 			  else
 			  {
 				  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and entering building name and room no. and entering area name and not selecting city and clicking next an alert did not appear-A defect");

 			  }
 		  }
 		  catch(Exception e)
 		  {
 			  System.out.println("alert did not appear");
 		  }
  	}

  	@When("^enter fn ln em cn np bn an city state status  blank  \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"  and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_fn_ln_em_cn_np_bn_an_city_state_status_blank_and_and_and_and_and_and_and_and_and(String fn, String ln, String em, String cn, String np, String bn, String an, String city, String state, String name) 
  	{
  		 pom=new Pomclass(d);
  	     pom.firstname(fn);
  	     pom.lastname(ln);
  	     pom.email1(em);
  	     pom.contact(cn);
  	     pom.number(np);	
  	     pom.building(bn); 
  	     pom.area(an);
  	     pom.city(city);
  	     pom.state(state);
  	     pom.radio(name);
  	     pom.next();
  	}

  	@Then("^alert message for status comes$")
  	public void alert_message_for_status_comes() 
  	{
  		try
		  {
			  String t1=d.switchTo().alert().getText();
			  d.switchTo().alert().accept();

			  System.out.println(t1);

			  if(t1.equalsIgnoreCase("Please Select MemeberShip status"))
			  {
				  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and entering building name and room no. and entering area name and not selecting city and clicking next an alert appeared-No defect");
			  }
			  else
			  {
				  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and entering building name and room no. and entering area name and not selecting city and clicking next an alert did not appear-A defect");

			  }
		  }
		  catch(Exception e)
		  {
			  System.out.println("alert did not appear");
		  }
  	}

  	@When("^enter all \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"  and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_all_and_and_and_and_and_and_and_and_and(String fn, String ln, String  em, String cn, String np, String bn, String an, String city, String state, String name) 
  	{
  	  
  		pom=new Pomclass(d);
 	     pom.firstname(fn);
 	     pom.lastname(ln);
 	     pom.email1(em);
 	     pom.contact(cn);
 	     pom.number(np);	
 	     pom.building(bn); 
 	     pom.area(an);
 	     pom.city(city);
 	     pom.state(state);
 	     pom.radio(name);
 	     pom.next();
  	}

  	@Then("^check for messages$")
  	public void check_for_messages() 
  	{
  		try
		  {
			  String t1=d.switchTo().alert().getText();
			  d.switchTo().alert().accept();

			  System.out.println(t1);

			  if(t1.equalsIgnoreCase("Personal details are validated."))
			  {
				  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and entering building name and room no. and entering area name and not selecting city and clicking next an alert appeared-No defect");
			  }
			  else
			  {
				  System.out.println("on entering first name and entering last name and entering email and entering contact no. and entering number of people and entering building name and room no. and entering area name and not selecting city and clicking next an alert did not appear-A defect");

			  }
		  }
		  catch(Exception e)
		  {
			  System.out.println("alert did not appear");
		  }
  		
  	}

  	@Then("^verify payment Details title$")
  	public void verify_payment_Details_title() 
  	{
  		String a=d.getTitle();
		    if(a.equalsIgnoreCase("Payment Details")) 
		    {
		        System.out.println("Title is correct-No defect");

		    }
		    else
		    {
		        System.out.println("Title is not correct-A defect");
		    }
			
  	    
  	}

  	@When("^holder blank and click makepayment$")
  	public void holder_blank_and_click_makepayment(DataTable dt) 
  	{
 List<List<String>> data = dt.raw();
  		 
  		 
  	     pom=new Pomclass(d);

  		 pom.holder(data.get(0).get(0));

  		 pom.makepay();
  	  
  	}
	@Then("^alert message for holder comes$")
  	public void alert_message_for_holder_comes() throws Throwable
  	{
		 try
		  {
			  String t=d.switchTo().alert().getText();
			  d.switchTo().alert().accept();

			  System.out.println(t);

			  if(t.equalsIgnoreCase("Please fill the Card holder name"))
			  {
				  System.out.println("on not entering holder name and clicking next and alert appeared-No defect");
			  }
			  else
			  {
				  System.out.println("on not entering holder name and clicking next and alert did not appeared-A defect");

			  }
		  }
		  catch(Exception e)
		  {
			  System.out.println("alert did not appear");
		  }
 	  
  	    
  	}

  	@When("^holder entered cardnumber blank and click makepayment$")
  	public void holder_entered_cardnumber_blank_and_click_makepayment(DataTable dt)  
  	{
 List<List<String>> data = dt.raw();
  		 
  		 
  	     pom=new Pomclass(d);

  		 pom.holder(data.get(0).get(0));
  		 pom.card(data.get(0).get(1));
  		 pom.makepay();
  	   
  	}

  	@Then("^alert message for card comes$")
  	public void alert_message_for_card_comes() throws Throwable
  	{
  	    

		 try
		  {
			  String t=d.switchTo().alert().getText();
			  d.switchTo().alert().accept();

			  System.out.println(t);

			  if(t.equalsIgnoreCase("Please fill the Debit card Number"))
			  {
				  System.out.println("on entering holder name and not entering card number and clicking next an alert appeared-No defect");
			  }
			  else
			  {
				  System.out.println("on entering holder name and not entering card number and clicking next an alert did not appeared-A defect");

			  }
		  }
		  catch(Exception e)
		  {
			  System.out.println("alert did not appear");
		  }
 		
  	}

  	@When("^enter holder cardnumber cvv blank \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_holder_cardnumber_cvv_blank_and_and(String h, String card, String cvv) 
  	{
  		 pom2=new Pomclass(d);
  	     pom2.holder(h);
  	     pom2.card(card);
  	     pom2.cvv(cvv);
  	     pom2.makepay();
  	  
  	}

  	@Then("^alert message for cvv comes$")
  	public void alert_message_for_cvv_comes() 
  	{
  		try
		  {
			  String t=d.switchTo().alert().getText();
			  d.switchTo().alert().accept();

			  System.out.println(t);

			  if(t.equalsIgnoreCase("Please fill the CVV"))
			  {
				  System.out.println("on entering holder name and entering card number and not entering cvv and clicking next an alert with text appeared-No defect");
			  }
			  else
			  {
				  System.out.println("on entering first name and entering card number and entering cvv and clicking next an alert with text did not appeared-A defect");

			  }
		  }
		  catch(Exception e)
		  {
			  System.out.println("alert did not appear");
		  }  
  	 
  	}

  	@When("^enter holder cardnumber cvv month blank \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_holder_cardnumber_cvv_month_blank_and_and_and(String h, String card, String cvv, String month) 
  	{
  		 pom2=new Pomclass(d);
  	     pom2.holder(h);
  	     pom2.card(card);
  	     pom2.cvv(cvv);
  	     pom2.mon(month);
  	     pom2.makepay();
  	    

  	}

  	@Then("^alert message for month comes$")
  	public void alert_message_for_month_comes() 
  	{

		 try
		  {
			  String t1=d.switchTo().alert().getText();
			  d.switchTo().alert().accept();

			  System.out.println(t1);

			  if(t1.equalsIgnoreCase("Please fill expiration month"))
			  {
				  System.out.println("on entering holder name and entering card number and entering cvv and not entering month and clicking next an alert with text appeared-No defect");
			  }
			  else
			  {
				  System.out.println("on entering holder name and entering card number and entering cvv and not entering month and clicking next an alert with text did not appear-A defect");

			  }
		  }
		  catch(Exception e)
		  {
			  System.out.println("alert did not appear");
		  }
  	}

  	@When("^enter holder cardnumber cvv month year blank \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void enter_holder_cardnumber_cvv_month_year_blank_and_and_and_and(String h, String card, String cvv, String month, String year) 
  	{
  		 pom2=new Pomclass(d);
  	     pom2.holder(h);
  	     pom2.card(card);
  	     pom2.cvv(cvv);
  	     pom2.mon(month);
  	     pom2.yer(year);
  	     pom2.makepay();
  	   
  	}

  	@Then("^alert message for year comes$")
  	public void alert_message_for_year_comes() 
  	{
  	  
  		 try
		  {
			  String t1=d.switchTo().alert().getText();
			  d.switchTo().alert().accept();

			  System.out.println(t1);

			  if(t1.equalsIgnoreCase("Please fill the expiration year"))
			  {
				  System.out.println("on entering holder name and entering card number and entering cvv and not entering month and  year entering clicking next an alert with text appeared-No defect");
			  }
			  else
			  {
				  System.out.println("on entering holder name and entering card number and entering cvv and not entering month and  year entering clicking next an alert with text did not appear-A defect");

			  }
		  }
		  catch(Exception e)
		  {
			  System.out.println("alert did not appear");
		  }
  	}

  	@When("^entering all payment \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
  	public void entering_all_payment_and_and_and_and(String h, String card, String cvv, String month, String year) 
  	{
  		 pom2=new Pomclass(d);
  	     pom2.holder(h);
  	     pom2.card(card);
  	     pom2.cvv(cvv);
  	     pom2.mon(month);
  	     pom2.yer(year);
  	   
  	     pom2.makepay();
  	}

  	@Then("^check message$")
  	public void check_message()
    {
  	  
  		try
		  {
			  String t1=d.switchTo().alert().getText();
			  d.switchTo().alert().accept();

			  System.out.println(t1);

			  if(t1.equalsIgnoreCase("Conference Room Booking successfully done!!!"))
			  {
				  System.out.println("on entering holder name and entering card number and entering cvv and  entering month and  year entering make payment entering  clicking next an alert with text appeared-No defect");
			  }
			  else
			  {
				  System.out.println("on entering holder name and entering card number and entering cvv and  entering month and  year entering  make payment clicking next an alert with text did not appear-A defect");

			  }
		  }
		  catch(Exception e)
		  {
			  System.out.println("alert did not appear");
		  }
  	}
 /**
 @After
 public void afterScenario1()
 {
   
   d.close();
 }
*/
}

